<script>
	import { onMount } from 'svelte';

	import Tools from '$lib/components/workspace/Tools.svelte';
</script>

<Tools />
