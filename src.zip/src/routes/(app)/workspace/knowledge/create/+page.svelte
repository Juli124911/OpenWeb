<script>
	import CreateKnowledgeBase from '$lib/components/workspace/Knowledge/CreateKnowledgeBase.svelte';
</script>

<CreateKnowledgeBase />
