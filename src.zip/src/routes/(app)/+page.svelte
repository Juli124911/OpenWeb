<script lang="ts">
	import Chat from '$lib/components/chat/Chat.svelte';
</script>

<Chat />
