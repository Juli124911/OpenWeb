<script>
	import Users from '$lib/components/admin/Users.svelte';
</script>

<Users />
